import { Usuarios } from '@/constants/Usuario';
import { Image, StyleSheet, Platform, View, Text, ViewComponent, FlatList, Pressable } from 'react-native';
import { Link } from 'expo-router';
import { Agendamentos } from '@/constants/Agendamento';

export default function HomeScreen() {
  return (
    
    <View style ={style.container}>
        <Link href="/Agendamentos"asChild>
        <Pressable>
            </Pressable>
            <Text>Servicos</Text>
                </Link>
      <Text style={style.TITLE}> Agendamentos </Text>
      <FlatList

      data={Agendamentos()}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({item}) => (
        <View style={style.Card}>
            <Text>ID: {item.id_agendamento}</Text>
            <Text>Nome: {item.data_agendamento}</Text>
            <Text>Horário: {item.hora_agendamento}</Text>
            <Text>Cliente: {<item.nome_cliente}</Text>
            <Text>Profissional: {item.nome_profissional}</Text>
        </View>
       )}
      />

      <Text style={{}}> Perfil Clientes</Text>
      <View style={{margin: 10, backgroundColor: 'ligtgray', padding: 10, flexDirection: 'row'}}>
      <Text style={{width: '33%'}}>Id</Text>
      <Text style={{width: '33%'}}>Nome do cliente</Text>
      <Text style={{width: '33%'}}>Nome do grupo</Text>
      </View>

        <Link href ="/agendamentos" asChild>
        <Pressable>
          <Text>agendamentos</Text>
        </Pressable>
            </Link>
             </View>
  );
}
const style = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#F5DEB3',
    },
    TITLE: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
    },
Card: {
    backgroundColor: 'white',
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,

},
nome: {
    fontSize: 18,
    fontWeight: 'bold',

},
    }
    
);