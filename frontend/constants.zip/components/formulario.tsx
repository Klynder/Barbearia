import { Text, View, TextInput} from 'react-native';

export default function Formulario(){
    return (
        <Text> Título do formulário</Text>
    )
}

export function Campo({label:label_name}){
    return (
        <View>
            <View>

                 <Text>{label_name}</Text>
                 <TextInput style={styles.campo}></TextInput>
            </View>
            
        </View>

    )
}
    const styles = StyleSheet.create({
        Campo:{
         backgroundColor: 'lightgray',
         padding: 5
       
        },
        texto:{
            color: "blue",
            fontwwight: "bold",
            fontsize: 18
        }
         },
       );
