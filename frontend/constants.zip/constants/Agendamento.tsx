const usuarios = [
    {
        id: " 1",
        nome: " Brian",
        nome_grupo: "profissional"


    },
    {
        id: " 2",
        nome: " Felipe",
        nome_grupo: "Cliente"


    },
    {
        id: " 3",
        nome: " Leandro",
        nome_grupo: "profissional"


    },
    {
        id: " 4",
        nome: " Joao",
        nome_grupo: "Cliente"


    },
    {
        id: " 5",
        nome: " Rodrigo",
        nome_grupo: "Cliente"


    },
    {
        id: " 6",
        nome: " Gemima",
        nome_grupo: "profissional"


    },
    {
        id: " 7",
        nome: " Ribeiro",
        nome_grupo: "Cliente"


    },
    {
        id: " 8",
        nome: " Carmo",
        nome_grupo: "Cliente"


    },
    {
        id: " 9",
        nome: " Paulo",
        nome_grupo: "Cliente"


    },
    {
        id: " 10",
        nome: " Jack",
        nome_grupo: "Cliente"


    },
   
]

export const Agendamentos = function (){
    return Agendamentos;
    
}
