const agenda = [
    {
        id_agenda: 2,
        dia:0,
        hora: "08:30"
    },
    {
        id_agenda: 1, 
        dia:5, 
        hora: "09:30",
    },
    {
        id_agenda: 3,
        dia:4,
        hora: "07:30"
    },
    {
        id_agenda: 4, 
        dia:3, 
        hora: "09:00",
    },
    {
        id_agenda: 5,
        dia:2,
        hora: "10:00"
    },
    {
        id_agenda: 7, 
        dia:6, 
        hora: "11:30",
    },
    {
        id_agenda: 9,
        dia:1,
        hora: "14:50"
    },
    {
        id_agenda: 8, 
        dia:5, 
        hora: "18:30",
    },

    {
        id_agenda: 11,
        dia:2,
        hora: "19:40"
    },
    {
        id_agenda: 12, 
        dia:6, 
        hora: "11:30",
    },
]
