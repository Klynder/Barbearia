const agendamentos = [
    {id_agendamento: 1, 
        data: "10/04/2025", 
        hora: "18:00", 
        nome_cliente: "Gustavo Henrique", 
        nome_profissional: "Jonhy Mark"},
        
    {id_agendamento: 1, 
        data: "15/10/2025", 
        hora: "14:30", 
        nome_cliente: "Marta Santos", 
        nome_profissional: "Jonhy Mark"},

    {id_agendamento: 1, 
        data: "30/04/2025", 
        hora: "14:30", 
        nome_cliente: "Gustavo Souza", 
        nome_profissional: "Jonhy Mark"},

    {id_agendamento: 1, 
        data: "25/05/2025", 
        hora: "14:00", 
        nome_cliente: "Carlos Lima", 
        nome_profissional: "Jonhy Mark"},

    {id_agendamento: 1, 
        data: "02/08/2025", 
        hora: "15:30", 
        nome_cliente: "Mark Spencer", 
        nome_profissional: "Jonhy Mark"},

    {id_agendamento: 1, 
        data: "03/07/2025", 
        hora: "11:30", 
        nome_cliente: "John Isaac", 
        nome_profissional: "Jonhy Mark"},

    {id_agendamento: 1, 
        data: "20/06/2025", 
        hora: "10:00", 
        nome_cliente: "Moises Carmo", 
        nome_profissional: "Jonhy Mark"},

    {id_agendamento: 1, 
        data: "31/05/2025", 
        hora: "08:00", 
        nome_cliente: "Hudson Menezes", 
        nome_profissional: "Jonhy Mark"},
]

export const Agendamentos = function(){
    return Agendamentos
}