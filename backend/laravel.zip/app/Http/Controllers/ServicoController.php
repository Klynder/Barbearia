<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Servico;

class ServicoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from UserController - index()";
    }
    public function getServico(){
        return response()->json([
            ["id" => 12, "nome" => "Maria Souza", "nome_grupo" => "cliente"],
            ["id" => 19, "nome" => "Gomes FGreire", "nome_grupo" => "cliente"],
            ["id" => 1, "nome" => "Karol", "nome_grupo" => "admin"],
            ["id" => 2, "nome" => "Nathy", "nome_grupo" =>"profissional"],
            ["id" => 3, "nome" => "Hanna", "nome_grupo" => "profissional"],
            ["id" => 4, "nome" => "Germano", "nome_grupo" => "profissional"],
            ["id" => 5, "nome" => "Cauê", "nome_grupo" => "profissional"],
            ["id" => 6, "nome" => "Flávia", "nome_grupo" => "cliente"],
            ["id" => 7, "nome" => "Bruno", "nome_grupo" => "cliente"],
            ["id" => 8, "nome" => "Josué", "nome_grupo" => "cliente"],
            ["id" => 9, "nome" => "Matheus", "nome_grupo" => "cliente"],
            ["id" => 10, "nome" => "Ludi", "nome_grupo" => "cliente"]
        ]);
    }
}
//id_agendamento | data _agendamento | hora_agendamento
//nome_profissional | nome_Cliente
